---
name: geoly-mcp
description: "Use when querying or reporting on AI brand visibility through GEOly — via the geoly CLI (geoly run / geoly call) or the GEOly MCP server: routing a question to the right entry point, following the org/brand discovery flow, quoting the correct KPI caliber, and avoiding metric-definition pitfalls. Triggers: GEOly; geoly CLI; GEO / AI-visibility reporting; citation rate, mention rate, AIGVR, Share of Model; daily trends; competitor, category whitespace, brand momentum; any call to get_brand_overview / query_analytics / get_prompt_* / get_citation_* / get_category_* / get_public_* tools."
metadata:
  author: geoly
  version: "0.7.0"
---

# GEOly MCP

[GEOly](https://www.geoly.ai) tracks how brands are mentioned and cited across AI engines (ChatGPT,
Perplexity, Google AI Mode, Google AI Overview, Gemini, Copilot). The MCP server exposes **up to 53 tools** (the exact set depends
on plan, mode, and write grants; a read-only multi-org connection sees 47) across two surfaces:

- **Self / brand-own** — the customer's own monitoring, audits, GA4, and write actions.
- **Public / industry** — cross-brand competitive intelligence (Grow tier and above).

The data is correct; **most mistakes are caliber mistakes** (mixing aggregations of the same
metric name) or **flow mistakes** (calling a brand tool before resolving which brand).

## First: which door are you at? (decide this before anything else)

There are two ways to reach GEOly and the right one is decided by **what is in this session**,
not by preference:

1. **The `geoly` CLI is on PATH** (check once: `geoly --version`) →
   **hand the question to `geoly run`** (CLI ≥ 0.3.0) — one command, see below. Do **not**
   rebuild the answer yourself out of `geoly tools` / `geoly schema` / `geoly call` chains: the
   hosted agent behind `run` already knows the calibers, routes the tools, handles timeouts and
   returns one receipt. The user installed the CLI precisely so that you would use it this way.
   `geoly call <tool>` is for a **specific raw pull** the user asked for by name, loops over many
   brands/prompts, or exports to files — not for answering questions.
   - **Version < 0.3.0** (no `run` subcommand): run `geoly upgrade` first (present since 0.1.0;
     self-updates the released binary) and re-check `geoly --version`. If it cannot upgrade
     (no route to the release host, not a released binary, user declines), **stay at this door
     in its older shape** — `geoly tools` → `geoly schema <tool>` → `geoly call <tool>`, using
     the tool-selection tables and calibers in this skill. Do **not** drop into the MCP
     pre-flight below: the CLI is installed, and the pre-flight only exists for hosts that have
     no CLI. (If the MCP tools also happen to be mounted, they are the same tools — either is
     fine.)
   - **Not signed in / credentials expired** (pre-installed CLI, never logged in; token expired;
     CI without `GEOLY_TOKEN`) — this is **exit code 3**, and it is still door 1, not a reason
     to switch doors. Any `geoly` command signs in lazily by itself; what you see depends on the
     machine:
     - browser available → it opens the browser and waits; a slow return is the user signing
       in, not a hang. Re-run the same command once it returns.
     - no local browser (SSH / container / Linux without a display — auto-detected, or force
       with `geoly auth login --remote`) → it prints a sign-in URL, then stops with exit 3 and a
       `next` line. Relay the URL to the user, run the `geoly auth login --code <code>` it
       printed, then re-run the command.
     - `CI=true` (or `--no-auto-auth`) → it fails fast with exit 3 and never opens anything:
       set `GEOLY_TOKEN` (a `geom_…` static token) and re-run.
     This is the same sign-in as step 2 of the bootstrap below; only the install step is
     skipped because the binary is already there.
2. **GEOly MCP tools are mounted** (`get_brand_overview`, `list_brands`, … in your tool list)
   and there is no CLI → use the tools directly with the rest of this skill.
3. **Neither** → the CLI is the fastest route to a working setup (one install line, one
   `geoly init`); see the CLI section. Only fall back to the MCP pre-flight below if the user's
   client is an MCP-only host (Claude Desktop, Cowork, cloud agents without a shell).

Never search for MCP tools for more than one try when the CLI is available, and never end a turn
by asking the user to run `geoly` themselves — you can run it.

## If the GEOly MCP tools aren't available in this session (pre-flight auto-authorize)

*(MCP-only hosts. If `geoly` is on PATH, skip this section — use the CLI.)*

If the GEOly MCP tools (e.g. `list_brands`, `get_brand_overview`) are **not** in your available
tool list, the `geoly` server may be unauthenticated or the session may have started before the
tools were mounted. If a tool is present but a call fails, **classify the error before taking any
auth action**. Do not turn every access error into a login loop:

| Error signal | What it means | Correct recovery |
|---|---|---|
| `AUTH_REQUIRED`, HTTP 401 with `WWW-Authenticate`, or the UI explicitly says unauthenticated | OAuth credentials are missing or invalid | Run the login flow below |
| `MCP_SETUP_REQUIRED` | The signed-in user has not completed workspace onboarding | Continue the browser setup opened by the MCP authorization flow; finish onboarding, then review the consent screen |
| `ORGANIZATION_REQUIRED` | GEOly could not find or prepare a usable organization | Ask the user to create/join an organization or contact GEOly support; do not re-login |
| `SUBSCRIPTION_REQUIRED`, `SUBSCRIPTION_INACTIVE`, or HTTP 402 | No selected organization has active entitlement | Send the user to `https://app.geoly.ai/settings/billing`; do not re-login |
| `ORG_SELECTION_REQUIRED` | The saved organization scope is no longer valid or includes unavailable organizations | Restart authorization and choose one active organization explicitly; do not re-login |
| Transport timeout / connection failure without an auth code | Network or client transport problem | Retry once, then inspect transport/client state; do not assume auth failure |

For a genuine auth-required or not-yet-mounted case, fix it **proactively** — don't make the user
hunt for the button, and do **not** probe the endpoint by hand (a raw HTTP request without the
stored OAuth token returns `401`, which is expected and proves nothing). Run this pre-flight, in
order:

1. **Open the sign-in window for them.** Only for the auth-required/not-mounted cases above, run
   the shell command `codex mcp login geoly`. For this
   OAuth (streamable-HTTP) server that starts the GEOly OAuth flow and opens the authorization page
   in the browser, so the user signs in with their GEOly account instead of hunting for the
   Authenticate button. (If a valid, unexpired login already exists, it usually completes without
   prompting for a new sign-in.) This command **blocks until the user finishes signing in** in the
   browser, so a slow return is normal — don't treat waiting as failure. They will still need to
   restart Codex (step 2) before the tools appear.
   - Only if you **cannot** run shell commands here, `codex` isn't on the PATH, or there is no
     browser available (headless): tell the user to click **Authenticate / 进行身份验证** next to
     `geoly` in **Settings → MCP servers**.
2. **Mount the tools.** GEOly's tools load at client startup, so after authorizing the user must
   fully **quit and reopen Codex** and start a **new** session — a new conversation in the
   still-running app is not enough (a fresh `codex exec` also loads them). Only then do
   `get_brand_overview` and the rest appear.
3. **If they still don't appear** after authorizing and a full restart, it's a client-side loading
   issue on Codex's side, not a GEOly problem — some Codex Desktop builds authenticate the server
   but never import its tools into the session. Have the user try the **Codex CLI** (`codex exec`,
   or a fresh CLI session), which is not affected by this Desktop import bug and generally mounts
   the tools after a fresh session.

Once the tools are mounted, continue with the user's request.

## Check for a newer version (once per session, non-blocking)

Your installed version is the `version` in this file's frontmatter (`metadata.version`). Before
your first GEOly tool call, do a quick, best-effort version check and mention it to the user only
if they're behind — then proceed with their request either way:

1. Read the latest published version: the `version` field of
   `https://raw.githubusercontent.com/geoly-ai/codex-plugins/main/plugins/geoly-mcp/.codex-plugin/plugin.json`
2. If that version is **newer** than your installed `metadata.version`, tell the user once, in one
   line: that a newer GEOly plugin (state the latest version) is available, they're on (state their
   installed version), and to update they should run `codex plugin marketplace upgrade geoly`, then
   `codex plugin add geoly-mcp@geoly`, then fully restart Codex / start a new session.
3. If the fetch fails, times out, or the versions already match, **say nothing** and continue. This
   check is best-effort and must never block or delay the user's actual request.

## Core Principles

**1. The KPI baseline is `get_brand_overview`.**
Its `aigvr.{score,mentionRate,citationRate}` are the headline numbers and match what the
customer sees in the GEOly app. Quote these for any "what is our citation/mention/visibility
rate" question. Nothing else is the headline.

**2. Never arithmetic-average a daily series.**
`query_analytics` (dataset `brand_citations_daily`) returns **per-day** rates; averaging them
over-weights low-volume days and will NOT match the headline. For a window number, use
`get_brand_overview`, the `recordCitationRate` metric, or re-aggregate daily rows **weighted by
`completedRecords`**. The same name `citationRate` has three legitimate calibers — see
references/metric-calibers.md.

**3. A gap in a daily line means "no monitoring ran that day", not a missing metric.**
Read `completedRecords` per row (0 or absent = no collection). AIGVR, mentionRate and
citationRate share one daily denominator, so they always have identical date coverage.

**4. Verify the caliber before you quote a number.**
mention ≠ citation; AIGVR ≠ Share of Model; record-rate ≠ URL counts; the competitor tool
(`get_platform_matrix` `dimension=competitor`) is record-weighted, never the headline. If
two numbers disagree, it is almost always a caliber/window/platform mismatch — reconcile, don't
guess.

**5. Resolve the brand before calling brand tools, then orient once with `get_brand_context`.**
In multi-brand / multi-org mode, call `list_brands` (and first `list_organizations`) and pass
`brand_id`. If a brand tool errors asking which brand, run the discovery tools first. Once the
brand is known, call `get_brand_context` **once** (free): it returns the brand and organization
(with the profile fields and GA4 / Cloudflare readiness), today's dates on all three axes (UTC /
business day / `record_date_key`), the first-collection state, the entitled platforms and which of
them have data in the last 30 days, topic ids plus the filter universe (countries, `_none`), the
tracked competitors on the **entity caliber** (the brand library — same rows as
`get_competitor_list status="tracked"`, own brand excluded), the data window and remaining
credits — so you do not spend separate calls on `get_current_date`, `get_topic_list` or
`get_public_coverage` view=`platforms` (scope=brand) afterwards; `get_competitor_list` is still the tool for suggestions,
removed brands and learned spellings.

**6. Recover from errors, don't loop.**
A `402` / "subscription inactive" or a missing `get_public_*` tool is a gating signal, not a
transient error — check mode, subscription, and plan tier before retrying. Respect truncation
markers (`_truncated`/`_shownCount` on brand tools; a plain-text `[truncated …]` marker on
public/report tools) and paginate (`currentPage == totalPages`) instead of assuming completeness.

## Connection & access (what affects your calls)

- **Auth**: the client connects to `https://app.geoly.ai/api/mcp/v1` (URL only; `/api/mcp` is the
  same v1 endpoint, kept for existing configs) and authorizes via
  OAuth in the browser on first use — the user picks the org and read/write scope on the consent
  screen. The authorization maps to a user and the orgs they can access. A legacy read-only
  `Authorization: Bearer geom_…` static token is still accepted for headless/CI. You may pin a
  single org with `?org_id=<id>` (takes precedence over the consent org scope).
- **Mode → discovery flow** (decides whether brand tools need a `brand_id`):
  - **single** (one org, one brand, or brand-bound token) → brand tools auto-resolve; just call them.
  - **multi-brand** (one org, many brands) → first `list_brands`, then pass `brand_id`.
  - **multi-org** (several orgs) → first `list_organizations`, then `list_brands`, then pass IDs.
  - `org_id` / `brand_id` are accepted by every brand tool in every mode (0.6.0). A token that
    cannot reach the requested org/brand gets an explicit error — it never silently falls back to
    its own default brand. If you see "cannot access org_id …", the token was consented for one
    org only: re-consent with all organizations (or use a token for that org).
  - Numeric parameters (`page`, `page_size`, `limit`, …) also accept numeric strings ("2").
  - In every mode, the first brand call of a session is `get_brand_context` (free, one shot):
    brand + org (+ profile fields, GA4/Cloudflare readiness) + today + first-run state + platforms
    (entitled ones included, even at 0 records) + topics + scope filters + entity-layer tracked
    competitors + data window + credits.
- **Public discovery flow** (any cross-brand / `get_public_*` work): **① `get_public_coverage`
  view=`data_window` (free)** → the "as of" anchor: public collection is a weekly batch and every public page windows
  its figures as "latest PUBLISHED batch day, back 30/60/90 days"; since 2026-09 the windowed
  public tools default to that 30d window (was: all history) and echo `window` in every response —
  keep all calls on one `range` and quote `window.from`–`window.to`. ② `search_public_entities` →
  ids/slugs. ③ `get_public_coverage` view=`locales` / view=`platforms` → a valid locale/platform.
  ④ the typed data tool (0.7.0: related public tools are **views** of one tool — `get_public_topic`,
  `get_public_brand` (incl. `brand_ids` comparison, perception, AIO rank×citation),
  `list_public_shopping_products` (incl. view=`boards`); old names unlisted — hidden, callable until 2026-11-30 and then removed; use the new ones — see CHANGELOG 0.7.0). Details: references/public-tools.md § Time window convention.
- **Reading a multi-view tool** (0.7.0): its description carries one line per view; the full
  caveats of each view (units, window exceptions, "null ≠ 0" rules) are in the description of the
  `view` / `mode` / `section` / `source` / `window_caliber` parameter, and a parameter's own limits
  in that parameter's description — read them before quoting a view's numbers.
- **Subscription gate**: single-org / single-brand context returns **HTTP 402** at entry if the
  subscription is inactive. Multi-org validates **per target org at call time** and fails that
  org's tool call with an error message (not a 402).
- **Public tools** require a **Grow-tier-or-above** plan (`grow | advanced | plus | enterprise`).
  Multi-org connections get them too, as long as **any** accessible org qualifies. If
  `get_public_*` / `get_category_*` aren't available, no accessible
  org has the tier or an active entitlement. (The three public **source** tools —
  `get_public_sources_overview` / `get_public_source_domain_detail` /
  `get_public_source_brand_conduit` — are NOT plan-gated and are **free**: every token has
  them and they never consume quota credits.)
- **Writes** (`create_prompt`, `create_topic`, `create_competitor`, `trigger_prompt`, `archive_prompt`, `update_prompt_tags`, `move_prompts_to_topic`) require
  **write access granted on the OAuth consent screen** (a per-resource read/write grid; the
  default is all-read, no-write). The legacy `geom_` static token is always read-only, and
  **multi-org connections are always read-only** (write grants are clamped). `trigger_prompt`
  really fires a scrape run (real work), so it always needs explicit intent — but it does
  **not** consume quota credits.
- **Dates**: take them from `get_brand_context.today` (`record_date_key` is the value the daily
  tools' `date` axis uses — one day behind the Asia/Shanghai business day) before building date
  ranges; `get_current_date` remains for the clock time. `query_analytics` ranges ≤ 366 days.
  Per-answer rows (`get_prompt_record_detail`, `list_prompt_records` (incl.
  `latest_per_platform=true`), `list_brand_answers` (both views), raw
  `get_prompt_citations`) carry `businessDay` (UTC+8
  `YYYY-MM-DD`, the date the app shows) — quote it, not the calendar date of `recordDate`
  (stored one day early as `(D−1)T16:00Z`).

## What costs credits (and what's free)

Credits come from one org-wide monthly pool (`get_quota` shows what is left). **The Cost line at
the end of every tool description is the authoritative price** — read it before looping over a tool.

- **Your own brand's monitoring reads cost credits per call** (since 2026-09-10): light 1 /
  standard 3 / deep 10 credits per call, whatever the page size — e.g. `get_brand_overview` 3,
  `get_citation_overview` 10 with `section="board"` / 3 with `section="table"`,
  `get_platform_matrix`, `get_topic_analytics` and `get_brand_search_queries` 10,
  `query_analytics` 1. Several are also rate-guarded per minute.
- **Public / industry-intelligence tools** (Grow-tier or above): the cross-brand `get_public_*` and
  `get_category_*` tools are paid per view (e.g. `get_public_topic` view=`difficulty`: 3 per call
  with a `topic_id`, 1 with a `prompt_id`, 10 with a `product_space_id`); the ranked-content
  listings `list_public_shopping_products` view=`boards` and `get_public_topic` view=`prompts` cost
  1 credit per row returned.
- **Free:** audits (`get_audit_list` / `get_audit_detail`), site traffic (`get_traffic_data`),
  `get_agent_ready_scans`, the writes (including `trigger_prompt`, which runs a real scrape but spends
  no quota credits), the three public source tools (`get_public_sources_overview` /
  `get_public_source_domain_detail` / `get_public_source_brand_conduit`), and all
  discovery/navigation (`get_brand_context`, `get_current_date`, `resolve_page_context`,
  `list_organizations`, `list_brands`, `get_topic_list`, `resolve_my_brand_public`,
  `search_public_entities`, `list_public_topics`, `get_public_coverage` (all three views),
  `get_quota`).

### Spending credits wisely

Credits are an org-wide monthly pool shared across all seats. To make them last **without
shipping a shallower report**:

1. **Discovery is always free — locate first, then pay to read.** Use the free
   `get_public_coverage` view=`data_window` (time anchor) / `search_public_entities` / `list_public_topics` /
   `get_public_search_queries` (mode `product_spaces`) to find the window and the exact
   topic/brand/space id **before** spending on content tools.
2. **Budget at the start of a multi-tool research task.** Call `get_quota` (free) once up front;
   if `remaining` is low, prioritise the calls that carry the conclusion. **`remaining` / `quota_limit`
   of `-1` means unlimited (enterprise)**: usage is still recorded and shown as `cost`, but a call is
   never rejected for lack of credits — do not budget or warn about a negative balance; the per-call
   2500-credit cap, rate limits and circuit breakers still apply.
3. **Budget by the Cost line, not by tier name.** Most public views are charged **per row of
   data returned** (1/3/10 per row by tier), so their cost scales with result size, not with the
   tool's "light/standard/deep" label. A single-object KPI (`get_public_brand` view=`visibility`)
   costs 10 — one row — while a 50-brand `leaderboard` costs 150 (50 rows × 3). Estimate such a call
   as `rows × per-row-rate`, and pass a `page_size`/`limit` no larger than you actually need (an
   over-large request pre-holds more, refunded down to the rows actually returned). Own-brand
   monitoring reads are the opposite — a flat price **per call** — so there one larger page is
   cheaper than several small ones.
4. **Two-stage, quality-gated.** Cheap tools (`overview` views, `1`-credit lookups) are for
   **triage/locating** — deciding what's worth a deep read. But when the answer depends on
   evidence (rankings, momentum, perception, per-prompt records, competitive standing), you
   **must** still call the deep tool (`get_public_topic` view=`prompt_matrix`, `get_public_brand`
   with `brand_ids` or view=`perception`, `get_public_topic_prompt_detail`, `get_category_*`). Never skip a
   deep call *to save credits* and hand back a thinner report — tell the user credits are low
   instead. Cost-efficiency means **not wasting** calls, not **under-delivering**.
5. **Don't blind-retry a wall.** `QUOTA_EXCEEDED` and `CIRCUIT_OPEN` are deterministic — retrying
   the identical call just fails again. Narrow the scope, switch to a cheaper tool that still
   answers, or tell the user the quota is exhausted (free tools still work). The `_quota` field on
   every paid result (`cost`, `remaining`, `warning`) is your running budget signal (`remaining: -1` =
   unlimited, never "overdrawn"). When a
   `QUOTA_EXCEEDED` says `max_affordable_limit`, retry the same tool with `page_size`/`limit` set
   to that value — a smaller page still returns everything for a small topic.

## GEOly CLI — how an agent uses it

The CLI ([github.com/geoly-ai/GEOly-Cli](https://github.com/geoly-ai/GEOly-Cli)) is the gh-style
entry point: the user signed in once, the credential stays on their machine, you run commands.
Same tools, same calibers, same login as the MCP server. `geoly <command> --help` is
authoritative for flags — read it rather than guessing.

**Answer a question: `geoly run` (the default move)**

```
geoly run "<the user's question, in their words>"            # brand defaults to the signed-in brand
geoly run "<question>" --brand <brand_id>                     # multi-brand tokens: pin the brand
geoly run "weekly health" --spec weekly-brand-health          # server-defined deliverables
geoly run "<question>" --max-credits 200                      # cap the spend
```

- stdout is one JSON receipt (`status`, `run_id`, `answer`, `credits_cost`, `credits_remaining`,
  `saved_to`); progress is on stderr. Read `answer`; the full receipt is also at
  `./.geoly/runs/<run_id>.json` — read that file for long answers instead of re-running.
- **`status` is the contract.** `done` = answer ready. `running` = still going on the server
  (the command waits ~100 s then returns so your shell does not time out) — **not** a failure:
  run the `next` command it prints (`geoly runs wait <run_id>`) to pick it up. Never re-issue
  the same `geoly run` (retries within 10 minutes are idempotent anyway). `failed` = read `error`.
- Put the user's actual question in — do not translate it into tool names. The hosted agent
  does the routing, the caliber discipline and the timeout handling; if a heavy query times out
  it retries or narrows the window itself. Your job is to relay the answer, add your own
  judgement, and cite `run_id` if the user wants to look it up.
- `geoly run <run_id>` shows a run's state; `geoly runs list` finds recent ones;
  `geoly credits` shows both credit pools before something expensive.

**Raw data: `geoly call` (only when the user asks for a specific pull, or for loops/exports)**

- `geoly tools --json` — tool names come from the server at runtime; never assume.
- `geoly call get_brand_context` (add `--brand_id <id>` in multi-brand orgs) as the first data
  call of a script: one JSON object with the brand, today's dates, the entitled platforms and
  which have data, topic ids, the tracked competitors (entity ids + legacy ids) and remaining
  credits — feed those into the loop instead of calling `get_current_date` /
  `get_competitor_list` / `get_public_coverage` view=`platforms` per iteration.
- `geoly schema <tool>` for exact parameters; `geoly call <tool> --help` also works.
- `geoly call <tool> --<param> <value> ...` — flags use schema parameter names **verbatim**
  (`--brand_id`, `--time_range 30d`); arrays/objects take JSON strings; whole-object via
  `--data '<json>'` or stdin via `--input -`. Results go to stdout as JSON (pipe to files).
- A `tool_error` on a heavy tool means the server timed out; narrow the window or use
  `geoly run` instead of retrying the same call.

**Exit codes** (from `geoly --help`): 0 ok (a `running` hand-off is also 0) / 1 tool or run error
/ 2 usage / 3 auth (sign in — see "Not signed in" under door 1; not a reason to leave the CLI)
/ 4 rate-limited / 5 subscription / 6 upstream / 7 credits exhausted.

**Bootstrap (only when `geoly` is not on PATH). "Headless" is about the browser, not the shell —
decide by what you have:**

| You have… | Do |
|---|---|
| A shell **and** a browser on this machine (laptop, desktop agent host) | Steps 1–3 below as written |
| A shell but **no** local browser (SSH, container, CI runner) | Do the bootstrap: step 1, then in step 2 sign in with `geoly auth login --remote` (paste-code) or `GEOLY_TOKEN`. This is the only route to a working setup here — do not skip it |
| **No shell at all**, or installs are forbidden (Claude Desktop, Cowork, a cloud agent that cannot run commands) | Skip the bootstrap; use the MCP pre-flight section above |

1. Install — zero-interaction, no sudo/admin:
   - macOS/Linux: `curl -fsSL https://geoly.ai/install.sh | sh`
   - Windows (from any shell): `powershell -ExecutionPolicy Bypass -c "irm https://geoly.ai/install.ps1 | iex"`
2. `geoly init` — opens the browser once for the user to sign in (a slow return while the
   browser is open is normal; wait, don't treat it as a failure) and installs this skill into the
   agent hosts on the machine. No browser on this machine (SSH, container)? `geoly auth login
   --remote` prints a sign-in URL; the user opens it anywhere and pastes the shown code back with
   `geoly auth login --code <code>`. Servers and CI set `GEOLY_TOKEN` instead; with `CI=true` the
   CLI fails fast (exit 3) rather than blocking.
3. Windows gotcha: `.env` files are not read — persist tokens with
   `[Environment]::SetEnvironmentVariable('GEOLY_TOKEN','geom_…','User')`.

## Tool selection — question → tool

### Self / brand-own
| You want… | Use |
|---|---|
| Orientation first: brand/org, today's dates, entitled + with-data platforms, topic & filter ids, entity-layer tracked competitors, credits | `get_brand_context` (free, once per run) |
| Headline KPI (AIGVR / mention / citation rate, whole window) | `get_brand_overview` |
| Daily/weekly **trend** of those metrics | `query_analytics` dataset=`brand_citations_daily`, `dimensions=["date","platform"]` |
| This period **vs the previous one** (week-over-week, month-over-month) with `days_with_data` | `query_analytics` with `compare_previous=true` (per-row `previous.*` / `delta.*`) |
| A topic / text-defined **subset** daily series | `query_analytics` dataset=`topic_citations_daily` (+ `prompt_text_include/exclude`) |
| Per-prompt visibility; search/list prompts (same calibers as the `/prompts` table; `summary` = the table's header bar) | `get_prompt_list` (per-prompt rate in `geoMetrics.aigvr.citationRate`; add `include_competitors=true` for SoM / competitors) |
| One prompt's windowed overview (visibility trend, Share of Mentions, competitor board, platform matrix, source domains — the `/prompts/[id]` page) | `get_prompt_detail` (`time_range` / `platform`) |
| Which competitors does the AI prefer **instead of** us, answer by answer (`weLose` per rival — the page's "who beats you" board; no weWin/tie any more) | `get_verdict` `view="competitors"` |
| Which cited sites ride along with **negative** aspect judgments of us (Verdict › Sources tab: `kind`, `citedRecords`, `negativeShare`) | `get_verdict` `view="sources"` (default 7d — the page shows 30d) |
| A prompt's **full execution history** over a range (per-day records, e.g. 30-day shopping-card trend) | `list_prompt_records` (explicit `start_date`/`end_date` are UTC+8 business days) |
| **Read the actual answers** brand-wide — every AI answer in the window, filtered by topic / tag / country / platform / "mentions entity X" / "mentions us", paginated (= in-app /performance/answers) | `list_brand_answers` (`answerSummary` + `entities[]` + `sources[]` per row; drill one row with `get_prompt_record_detail`) |
| The actual **citation URLs / sources** for a prompt | `get_prompt_citations` (`deduplicate=true` for a source list) |
| "Which queries never mention us" (blind spots) | `get_prompt_list` `view="mention_rates"` (worst first by default) |
| Citation **domain distribution / ownership** | `get_citation_overview` (counts URLs, not records; window = N whole +08 calendar days + today on the citation-creation axis — read `caliber` + `window` from the response) |
| One domain / one page deep-dive | `get_domain_detail` (the `/sources/citations/<root_domain>` drill-down) / `get_url_detail` — pick the caliber: `window_caliber="page"` (same `caliber` + `window` contract as the domain drill-down; `share` raw 0–1, shown with one decimal — but **not** the pages-tab row: lookup-URL grain and a denominator that keeps redirect links) or `window_caliber="rolling"` (default; tool-only: lookup-URL grain + rolling or custom `[start_date, end_date)` window, adds ChatGPT search sources and `prompt_id` filter — not a page row) |
| The cited-domain table: per-domain delta, mentioned brands, "mentions you", search / sort / paging | `get_citation_overview` `section="table"` (same read model as the page) |
| Content gaps (competitor cited there, you not) | `get_citation_overview` `section="table"`, `gap_only=true` (domains, the page caliber; for one domain's prompts use `get_domain_detail` `prompts[]`) |
| Standing **vs competitors** | `get_brand_board` (**entity caliber** — unfiltered it *is* the in-app /performance board: confirmed competitors, `visibility` = mentioned ÷ completed answers, same formula for you; `include_trend=true` for the page's daily chart — **not one point per day**: check `trendLatestDay` (yesterday is often still uncounted) and `trendTruncated` (long windows keep the newest days only). Adding `topic_ids`/`country` switches to `caliber=scoped_open_world_v0`: same row source as the page's filtered board but **different numbers** — the page still shows the legacy merged board there, fail-closed) · `get_platform_matrix` `dimension=competitor` (legacy discovered-brand record-weighted — not headline) |
| How AI *describes* the brand (verbatim) | `list_brand_answers` `view="mention_samples"`; vs rivals → `get_competitor_cooccurrence` |
| Topic-level analysis | `get_topic_list` (ids, free) → `get_topic_analytics` (pass `topic_ids`) or `query_analytics` `topic_citations_daily` for day-level topic trends |
| Sentiment (brand-wide distribution / daily trend / per platform — no verbatim highlights, use `list_brand_answers` `view="mention_samples"` for those) | `get_sentiment_dashboard` |
| The brand library (own brand + tracked competitors + system suggestions + removed), same rows as Settings › Brand | `get_competitor_list` (competitors = `status="tracked"` and `is_own_brand=false`) |
| Site AI-readiness audit | `get_audit_list` → `get_audit_detail` (the report header + single-page checks + fix copy in `checksMeta`) → `get_audit_detail` `section="pages"` for a site audit's per-page results / `fetch_quality=unusable` pages |
| Traffic (if GA4 connected) | `get_traffic_data` `source="ga4"` (add `page_path` for one page). Whole-site vs AI-referred fields live in the same payload — see the catalog row before quoting a number; the page opens on 7d, the tool defaults to 30d |
| AI crawlers hitting the site (if Cloudflare connected) | `get_traffic_data` `source="cloudflare"` — bots fetching pages, **not** visitors arriving from AI answers (that is `source="ga4"`). Two calibers to keep straight: `changes.blockedEvents` is always `null` (never computed), and `blockedEvents[]` is capped at 50 rows (`blocked_events_limit`) — quote per-crawler block counts from the uncapped `blockedCrawlerSummary` |
| Archived prompts — list them | `get_prompt_list status=archived` (the /prompts Archived tab; no separate read tool). `get_prompt_detail` / `get_prompt_record_detail` work on archived prompts by id |
| Archive / restore a prompt | `archive_prompt` (write grant; `restore=true` to bring it back; idempotent). Archived prompts refuse `trigger_prompt` until restored |
| Tag prompts in bulk / rename a tag | `update_prompt_tags` (write grant): `action=add\|remove` with `prompt_ids` + `tags`; `action=rename` with `old_name` + `new_name` |
| Move prompts to a topic / ungroup | `move_prompts_to_topic` (write grant): `prompt_ids` + `topic_id` from `get_topic_list`, or `topic_id=null` |

> `display_data` / `display_chart` and `web_search` / `fetch_page` are **in-app agent only** —
> not exposed over MCP. MCP results are plain JSON (no `_ref`).
>
> `get_prompt_list` computes SoM / competitors only when you pass `include_competitors=true`
> (default rows carry `competitorsDeferred: true` and omit `som` / `competitorMentions`, like the
> page's first screen). `get_prompt_detail` is **windowed** (default 30 days) — its numbers are
> not comparable to the old all-time payload (`include_lifetime=true` still returns that,
> deprecated).

### Public source domains (every token — no plan gate)
| You want… | Use |
|---|---|
| Most-cited source domains across all AI answers, each with its **AI DA** (0–100 domain authority) | `get_public_sources_overview` |
| One source domain's profile; add `include_scorecard=true` for the AI DA breakdown (authority/placement/breadth + rank/momentum/integrity) | `get_public_source_domain_detail` |
| **Which topics a source funnels AI toward a brand** ("where does reddit.com steer AI to competitor X?") | `get_public_source_brand_conduit` |

### Public / industry (Grow tier and above)
| You want… | Use |
|---|---|
| The "as of" date + 30/60/90d windows the public pages use (call first; free) | `get_public_coverage` view=`data_window` |
| Valid locales / platforms for an entity or scope (free) | `get_public_coverage` view=`locales` / `platforms` |
| Resolve a brand/category/topic name → IDs | `search_public_entities` |
| Category leaderboard / who leads | `get_public_category` view=`brand_leaderboard` |
| Where to invest (winnable topics) | `get_category_whitespace` |
| Who's gaining/losing share | `get_category_brand_momentum` |
| What AI is being asked in our space | `get_public_search_queries` mode=`territories` → same tool, mode=`query_detail` |
| Which brand OWNS each cross-topic demand root | `get_public_search_queries` mode=`territories` |
| Cross-category **AI shelf leaderboard** (hot / climbers / entrants, week-over-week) | `list_public_shopping_products` view=`boards` |
| One category's AI shelf (latest batch vs previous, channels, price tiers) | `list_public_shopping_products` (view=`products`, default) |
| One product's full AI analysis (shelves, trend, rivals, channels) | `get_public_shopping_product_detail` (mode=`card` for a cheap preview) |
| One topic: overview, leaderboard, SoM trend, prompt matrix, every prompt, citation domains, commerce | `get_public_topic` view=`overview` / `brand_leaderboard` / `som_trend` / `prompt_matrix` / `prompts` / `citation_domains` / `commerce` |
| Compare 2–4 brands head-to-head | `get_public_brand` with `brand_ids` + `view` (e.g. `visibility`; country+language **required**) |
| How AI perceives a brand | `get_public_brand` view=`perception` → view=`perception_mentions` |
| Does Google ranking convert into AI Overview citations (AIO only) | `get_public_brand` view=`rank_citation` → view=`rank_citation_rows` |
| Is a topic worth targeting | `get_public_topic` view=`difficulty` |
| Bridge my brand → public dataset | `resolve_my_brand_public` (`bestMatch` = the in-app industry-profile decision; `ambiguous=true` means the app refuses to pick — do not guess from `candidates`) |

Cross-ref rule: for record counts/rates use `get_brand_overview` (not `get_citation_overview`,
which counts URLs); for trends use `query_analytics` dataset=`brand_citations_daily` (not by
paginating citations).
Window rule for the page-window citation tools (`get_citation_overview` / `get_domain_detail` /
`get_url_detail window_caliber="page"`): their `time_range` is **N whole Asia/Shanghai calendar days on the
citation-creation axis plus today** (matches the /sources/citations page), not the rolling
`now − N×24h` preset window of `get_brand_overview` (whose `custom` range is instead an exact
+08 business-day span, echoed as full ISO instants) — never subtract one from the other; quote the
`window` each response returns. Their `platform` (and `get_url_detail`'s rolling caliber)
must be `all` or an **active** platform the brand is entitled to
(exactly the page's platform chips) — an unknown, un-entitled or retired code (e.g. a
`claude` / `grok` entry left in an old entitlement list) returns `{ error }` listing the
allowed codes, never a silent fall-back to all. Shares: the page shows one decimal — format
the raw `share` (0–1) fields; integer `percentage` / `ownership` points cannot be turned back
into the page's number. `caliber="legacy"` means the derived layer was unavailable and
the old query ran instead — its `window` then differs by tool: `get_citation_overview` reports
`startDay..endDay` **business days (+08)** on `prompt_record.record_date` (the old predicate is
day-granular, not an instant); `get_domain_detail` / `get_url_detail` (page caliber) report an exact
`start..end` instant pair on citation `created_at` (rolling N×24h). Quote whichever you got.

> No deprecated aliases are listed (0.7.0): the brand-own and public old names — including the
> 0.6.x forwarding aliases — left `tools/list`. `/api/mcp/v1` (also served at `/api/mcp`) is MCP v1
> (`GEOly-MCP-Version: 1`); the 34 old names are not part of v1: they stay hidden and callable until 2026-11-30 and are then
> removed (the three non-drop-in ones — `get_competitor_overview`, `get_brand_citations_daily`,
> `get_content_opportunities` — already only return a free `TOOL_REMOVED` notice); always call the
> new names. Old → new: tools-catalog § Pre-0.7.0 brand-own names and § Pre-0.7.0 public names
> (also CHANGELOG 0.7.0 § Versioning).

## Recipes

**KPI baseline (always start here)**
```json
{ "tool": "get_brand_overview", "args": { "time_range": "30d" } }
```
Read `aigvr.citationRate` / `aigvr.mentionRate` / `aigvr.score` — the report headline.

**Honest daily trend**
```json
{ "tool": "query_analytics",
  "args": { "dataset": "brand_citations_daily", "dimensions": ["date","platform"],
            "metrics": ["completedRecords","aigvr","mentionRate","citationRate","citationCount"],
            "start_date": "2026-05-28", "end_date": "2026-06-26" } }
```
Plot as-is; treat absent days as "no collection" (check `completedRecords`). For a window value,
weight daily rates by `completedRecords` — don't simple-average.

**Citation sources for a prompt**
```json
{ "tool": "get_prompt_citations",
  "args": { "prompt_id": "<id>", "deduplicate": true, "limit": 500 } }
```

**Text-defined subset (e.g. non-branded), 3-metric daily series**
```json
{ "tool": "query_analytics",
  "args": { "dataset": "topic_citations_daily", "dimensions": ["date"],
            "metrics": ["aigvr","mentionRate","citationRate"],
            "prompt_text_exclude": "<brandword>",
            "start_date": "2026-05-28", "end_date": "2026-06-26" } }
```

**Period-over-period in one call (delta per platform, with coverage check)**
```json
{ "tool": "query_analytics",
  "args": { "dimensions": ["platform"], "metrics": ["completedRecords","mentionRate","citationRate"],
            "start_date": "2026-09-13", "end_date": "2026-09-19", "compare_previous": true } }
```
Each row carries `previous.mentionRate` / `delta.mentionRate` (percentage points). Quote
`window.current.days_with_data` vs `window.previous.days_with_data` alongside the delta — if the
current window has fewer collection days, say so instead of calling the change a trend.

**Competitive: where can we win a category**
```json
{ "tool": "search_public_entities", "args": { "query": "<my brand or category>" } }
```
→ `get_category_whitespace` with the resolved `product_space_id` + `public_brand_id`; act on the
`prioritize` / `gap` buckets.

## Reference Guides

- **Metric calibers, glossary & limits** → [references/metric-calibers.md](references/metric-calibers.md)
  **MUST read when** quoting any rate/score, reconciling two numbers that disagree, building a
  trend, or hitting a row/date/rate limit.
- **Full tool catalog (all registered tools + parameters)** → [references/tools-catalog.md](references/tools-catalog.md)
  **MUST read when** you need a tool's exact parameters/enums/defaults, or to confirm whether a
  tool is exposed over MCP.
- **Public / industry competitive-intelligence tools** → [references/public-tools.md](references/public-tools.md)
  **MUST read when** doing cross-brand work (leaderboards, whitespace, momentum, AI-search
  demand, perception, shopping) or anything involving the locale convention.
